<?php
die(json_encode(array('Code'=>'10001','Name'=>'abcde','Score'=>100)));   
?>