<?php
	/*
	 获取接收的数据编号，删除对应记录
	 ...
	*/
	//返回已删除成功标志
	die(json_encode(array('code'=>'0')));
?>