﻿require(["../Script/jquery-1.8.2.min"], function () {
    $("#tip").html("hello，require！");
});