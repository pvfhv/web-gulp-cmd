﻿define({
    name: "陶国荣",
    sex: "男",
    email: "tao_guo_rong@163.com"
});